/**
 * 
 */
package com.gaduo.zk.model.iti_18;

import java.util.List;

import org.apache.axiom.om.OMElement;

/**
 * @author Gaduo
 *
 */
public interface IParameter{

    public List<OMElement> getParameters();
    
}
