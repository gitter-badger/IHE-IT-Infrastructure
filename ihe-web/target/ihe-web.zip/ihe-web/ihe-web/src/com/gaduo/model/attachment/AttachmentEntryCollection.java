package com.gaduo.model.attachment;

import java.util.LinkedList;

import org.zkoss.zul.DefaultTreeNode;


/**
 * @author Gaduo
 *
 */
public class AttachmentEntryCollection<T> extends LinkedList<DefaultTreeNode<T>> {

    private static final long serialVersionUID = 1L;

}
